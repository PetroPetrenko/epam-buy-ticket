package com.example.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Доменные исключения приложения.
 *
 * Принцип: исключения несут HTTP-статус через @ResponseStatus,
 * что позволяет GlobalExceptionHandler обрабатывать их единообразно.
 */
public final class CustomerException {

    private CustomerException() {}

    @ResponseStatus(HttpStatus.NOT_FOUND)
    public static class NotFound extends RuntimeException {
        public NotFound(Long id) {
            super("Customer not found: id=" + id);
        }
    }

    @ResponseStatus(HttpStatus.CONFLICT)
    public static class EmailAlreadyExists extends RuntimeException {
        public EmailAlreadyExists(String email) {
            super("Email already registered: " + email);
        }
    }
}

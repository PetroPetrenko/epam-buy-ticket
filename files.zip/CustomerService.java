package com.example.service;

import com.example.dto.CustomerDto;
import com.example.entity.Customer;
import com.example.exception.CustomerException;
import com.example.repository.CustomerRepository;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Сервисный слой — вся бизнес-логика здесь, не в контроллере.
 *
 * Принципы:
 *  - @Transactional(readOnly = true) на методах чтения — оптимизация Hibernate
 *    (отключает dirty checking, flush mode = NEVER).
 *  - Контроллер получает только DTO, entity не покидают сервисный слой.
 *  - Все исключения — доменные (не Spring DataAccessException).
 */
@Service
@Transactional(readOnly = true)   // default для всего класса
public class CustomerService {

    private final CustomerRepository repo;

    // Constructor injection (лучше @Autowired на поле)
    public CustomerService(CustomerRepository repo) {
        this.repo = repo;
    }

    // ── Чтение ───────────────────────────────────────────────────────────────

    public CustomerDto.PageResponse<CustomerDto.Response> findAll(int page, int size, String sort) {
        var pageable = PageRequest.of(page, size, Sort.by(sort));
        Page<CustomerDto.Response> result = repo.findAll(pageable)
                .map(CustomerDto.Response::from);
        return toPageResponse(result);
    }

    public CustomerDto.Response findById(Long id) {
        return repo.findById(id)
                .map(CustomerDto.Response::from)
                .orElseThrow(() -> new CustomerException.NotFound(id));
    }

    public CustomerDto.PageResponse<CustomerDto.Response> search(
            String keyword, int page, int size) {
        var pageable = PageRequest.of(page, size, Sort.by("name"));
        Page<CustomerDto.Response> result = repo.search(keyword, pageable)
                .map(CustomerDto.Response::from);
        return toPageResponse(result);
    }

    // ── Запись ───────────────────────────────────────────────────────────────

    @Transactional   // переопределяет readOnly = true для мутирующих операций
    public CustomerDto.Response create(CustomerDto.CreateRequest req) {
        if (repo.findByEmail(req.email()).isPresent()) {
            throw new CustomerException.EmailAlreadyExists(req.email());
        }
        Customer saved = repo.save(new Customer(req.name(), req.email(), req.address()));
        return CustomerDto.Response.from(saved);
    }

    @Transactional
    public CustomerDto.Response update(Long id, CustomerDto.UpdateRequest req) {
        Customer customer = repo.findById(id)
                .orElseThrow(() -> new CustomerException.NotFound(id));

        // Проверяем уникальность email, исключая текущего клиента
        if (repo.existsByEmailAndIdNot(req.email(), id)) {
            throw new CustomerException.EmailAlreadyExists(req.email());
        }

        customer.setName(req.name());
        customer.setEmail(req.email());
        customer.setAddress(req.address());
        // save() не нужен — dirty checking Hibernate сохранит изменения при commit

        return CustomerDto.Response.from(customer);
    }

    @Transactional
    public void delete(Long id) {
        if (!repo.existsById(id)) {
            throw new CustomerException.NotFound(id);
        }
        repo.deleteById(id);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private <T> CustomerDto.PageResponse<T> toPageResponse(Page<T> page) {
        return new CustomerDto.PageResponse<>(
                page.getContent(),
                page.getNumber(),
                page.getSize(),
                page.getTotalElements(),
                page.getTotalPages()
        );
    }
}

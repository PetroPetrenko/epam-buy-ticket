package com.example.repository;

import com.example.entity.Customer;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

/**
 * Spring Data JPA репозиторий.
 *
 * Принципы:
 *  - Не наследуем CrudRepository — используем JpaRepository для поддержки
 *    Pageable и batch-операций.
 *  - Кастомные запросы через JPQL (не native SQL) для переносимости.
 *  - Возвращаем Optional<> где запись может отсутствовать.
 */
public interface CustomerRepository extends JpaRepository<Customer, Long> {

    /**
     * Проверка уникальности email при обновлении:
     * существует ли другой клиент с таким же email.
     */
    boolean existsByEmailAndIdNot(String email, Long id);

    /**
     * Полнотекстовый поиск по name / email / address с пагинацией.
     * LOWER() обеспечивает case-insensitive поиск без зависимости от collation БД.
     */
    @Query("""
            SELECT c FROM Customer c
            WHERE LOWER(c.name)    LIKE LOWER(CONCAT('%', :kw, '%'))
               OR LOWER(c.email)   LIKE LOWER(CONCAT('%', :kw, '%'))
               OR LOWER(c.address) LIKE LOWER(CONCAT('%', :kw, '%'))
            """)
    Page<Customer> search(@Param("kw") String keyword, Pageable pageable);

    /** Поиск по точному email — для проверки дублей при создании. */
    Optional<Customer> findByEmail(String email);
}

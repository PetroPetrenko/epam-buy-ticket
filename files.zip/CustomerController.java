package com.example.controller;

import com.example.dto.CustomerDto;
import com.example.service.CustomerService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

/**
 * ─────────────────────────────────────────────────────────────────────────────
 *  CustomerController  —  REST CRUD с виртуальными потоками (Java 21 Loom)
 * ─────────────────────────────────────────────────────────────────────────────
 *
 *  Виртуальные потоки (Virtual Threads):
 *  ┌─────────────────────────────────────────────────────────────────────────┐
 *  │  В application.properties добавить:                                     │
 *  │    spring.threads.virtual.enabled=true                                  │
 *  │                                                                         │
 *  │  Spring Boot 3.2+ автоматически переводит Tomcat на виртуальные         │
 *  │  потоки. Каждый HTTP-запрос выполняется в лёгком виртуальном потоке     │
 *  │  (~1 КБ stack vs ~512 КБ для platform thread), что позволяет            │
 *  │  обрабатывать десятки тысяч одновременных запросов без reactive-стека.  │
 *  │                                                                         │
 *  │  При блокирующих вызовах (JDBC, HTTP-клиент) виртуальный поток          │
 *  │  «паркуется» и не блокирует carrier thread — JVM продолжает работу.    │
 *  └─────────────────────────────────────────────────────────────────────────┘
 *
 *  REST-контракт:
 *    GET    /api/v1/customers              — список с пагинацией
 *    GET    /api/v1/customers/{id}         — один клиент
 *    GET    /api/v1/customers/search?q=    — поиск
 *    POST   /api/v1/customers              — создать  → 201 Created
 *    PUT    /api/v1/customers/{id}         — заменить → 200 OK
 *    DELETE /api/v1/customers/{id}         — удалить  → 204 No Content
 *
 *  Лучшие практики применённые здесь:
 *   ✓ @Validated на классе  — поддержка @Min/@Max на параметрах запроса
 *   ✓ @Valid на @RequestBody — запускает Bean Validation на DTO
 *   ✓ ResponseEntity<>      — явный контроль HTTP-статусов и заголовков
 *   ✓ Location header       — возвращается после 201 Created (RFC 7231)
 *   ✓ Нет бизнес-логики     — контроллер только маршрутизирует
 *   ✓ Версионирование API   — /api/v1/... в пути
 *   ✓ Логирование через SLF4J (не System.out.println)
 */
@RestController
@RequestMapping("/api/v1/customers")
@Validated  // включает валидацию @RequestParam / @PathVariable
public class CustomerController {

    private static final Logger log = LoggerFactory.getLogger(CustomerController.class);

    private final CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    // ── GET /api/v1/customers?page=0&size=20&sort=name ────────────────────────

    /**
     * Возвращает постраничный список клиентов.
     *
     * @param page  номер страницы (0-based), по умолчанию 0
     * @param size  размер страницы, 1–100, по умолчанию 20
     * @param sort  поле сортировки, по умолчанию "name"
     */
    @GetMapping
    public ResponseEntity<CustomerDto.PageResponse<CustomerDto.Response>> findAll(
            @RequestParam(defaultValue = "0")  @Min(0)        int page,
            @RequestParam(defaultValue = "20") @Min(1) @Max(100) int size,
            @RequestParam(defaultValue = "name")               String sort
    ) {
        log.debug("GET /customers page={} size={} sort={}", page, size, sort);
        return ResponseEntity.ok(customerService.findAll(page, size, sort));
    }

    // ── GET /api/v1/customers/{id} ────────────────────────────────────────────

    @GetMapping("/{id}")
    public ResponseEntity<CustomerDto.Response> findById(@PathVariable Long id) {
        log.debug("GET /customers/{}", id);
        return ResponseEntity.ok(customerService.findById(id));
        // 404 если не найден — бросается в сервисе, перехватывается GlobalExceptionHandler
    }

    // ── GET /api/v1/customers/search?q=john&page=0&size=20 ───────────────────

    @GetMapping("/search")
    public ResponseEntity<CustomerDto.PageResponse<CustomerDto.Response>> search(
            @RequestParam("q")                                  String keyword,
            @RequestParam(defaultValue = "0")  @Min(0)         int page,
            @RequestParam(defaultValue = "20") @Min(1) @Max(100) int size
    ) {
        log.debug("GET /customers/search q='{}' page={} size={}", keyword, page, size);
        return ResponseEntity.ok(customerService.search(keyword, page, size));
    }

    // ── POST /api/v1/customers ────────────────────────────────────────────────

    /**
     * Создаёт нового клиента.
     * Возвращает 201 Created + Location: /api/v1/customers/{id}
     */
    @PostMapping
    public ResponseEntity<CustomerDto.Response> create(
            @Valid @RequestBody CustomerDto.CreateRequest req,
            UriComponentsBuilder ucb
    ) {
        log.info("POST /customers email={}", req.email());
        CustomerDto.Response created = customerService.create(req);

        var location = ucb
                .path("/api/v1/customers/{id}")
                .buildAndExpand(created.id())
                .toUri();

        return ResponseEntity.created(location).body(created);
    }

    // ── PUT /api/v1/customers/{id} ────────────────────────────────────────────

    /**
     * Полностью заменяет данные клиента (идемпотентная операция).
     * Для частичного обновления использовать PATCH (здесь не показан для краткости).
     */
    @PutMapping("/{id}")
    public ResponseEntity<CustomerDto.Response> update(
            @PathVariable Long id,
            @Valid @RequestBody CustomerDto.UpdateRequest req
    ) {
        log.info("PUT /customers/{}", id);
        return ResponseEntity.ok(customerService.update(id, req));
    }

    // ── DELETE /api/v1/customers/{id} ─────────────────────────────────────────

    /**
     * Удаляет клиента. Возвращает 204 No Content (тело отсутствует).
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        log.info("DELETE /customers/{}", id);
        customerService.delete(id);
        return ResponseEntity.noContent().build();
    }
}

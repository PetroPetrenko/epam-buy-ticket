package com.example.dto;

import com.example.entity.Customer;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;

/**
 * DTO-слой на основе Java Records (Java 16+).
 *
 * Принципы:
 *  - Входящие данные (Request) и исходящие данные (Response) разделены.
 *  - Никаких entity на граничах API — защита от over-posting атак.
 *  - Валидация только во входящих DTO.
 */
public final class CustomerDto {

    private CustomerDto() {} // utility class, не инстанциировать

    // ── Request DTO (входящие данные) ─────────────────────────────────────────

    /**
     * Используется для POST /customers  (создание).
     */
    public record CreateRequest(
            @NotBlank @Size(max = 100) String name,
            @NotBlank @Email @Size(max = 150) String email,
            @Size(max = 255) String address
    ) {}

    /**
     * Используется для PUT /customers/{id}  (полное обновление).
     * Все поля обязательны.
     */
    public record UpdateRequest(
            @NotBlank @Size(max = 100) String name,
            @NotBlank @Email @Size(max = 150) String email,
            @Size(max = 255) String address
    ) {}

    // ── Response DTO (исходящие данные) ───────────────────────────────────────

    /**
     * Полный ответ с метаданными времени.
     */
    public record Response(
            Long id,
            String name,
            String email,
            String address,
            LocalDateTime createdAt,
            LocalDateTime updatedAt
    ) {
        /** Фабричный метод — маппинг entity → DTO без MapStruct для ясности. */
        public static Response from(Customer c) {
            return new Response(
                    c.getId(),
                    c.getName(),
                    c.getEmail(),
                    c.getAddress(),
                    c.getCreatedAt(),
                    c.getUpdatedAt()
            );
        }
    }

    // ── Pagination wrapper ────────────────────────────────────────────────────

    /**
     * Универсальная обёртка для постраничных ответов.
     */
    public record PageResponse<T>(
            java.util.List<T> content,
            int page,
            int size,
            long totalElements,
            int totalPages
    ) {}
}

package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.core.task.support.TaskExecutorAdapter;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.servlet.config.annotation.AsyncSupportConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.concurrent.Executors;

@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}

/**
 * ─────────────────────────────────────────────────────────────────────────────
 *  Конфигурация Virtual Threads (Java 21 Project Loom)
 * ─────────────────────────────────────────────────────────────────────────────
 *
 *  Способ 1 (рекомендуемый для Spring Boot 3.2+):
 *    В application.properties:
 *      spring.threads.virtual.enabled=true
 *    Spring Boot сам настроит Tomcat и @Async на виртуальные потоки.
 *
 *  Способ 2 (ручная конфигурация ниже) — для понимания механизма
 *  или если нужен точный контроль.
 *
 *  КАК РАБОТАЮТ VIRTUAL THREADS:
 *  ┌───────────────────────────────────────────────────────────────────────┐
 *  │                                                                       │
 *  │   HTTP Request                                                        │
 *  │       │                                                               │
 *  │       ▼                                                               │
 *  │  [Virtual Thread]  ──── mount ────►  [Carrier Thread (platform)]     │
 *  │       │                                                               │
 *  │       │  JDBC call (blocking I/O)                                     │
 *  │       │                                                               │
 *  │       ▼                                                               │
 *  │  [Virtual Thread]  ◄─── unmount ──  [Carrier Thread] ──► другой VT  │
 *  │     (parked)                                                          │
 *  │       │                                                               │
 *  │       │  I/O завершён                                                 │
 *  │       ▼                                                               │
 *  │  [Virtual Thread]  ──── mount ────►  [Carrier Thread]               │
 *  │                                                                       │
 *  │  Результат: 1 carrier thread обслуживает тысячи виртуальных потоков  │
 *  └───────────────────────────────────────────────────────────────────────┘
 */
@Configuration
@EnableAsync
class VirtualThreadConfig implements WebMvcConfigurer {

    /**
     * Executor на базе виртуальных потоков для @Async методов.
     * Каждая задача получает собственный виртуальный поток — никакого пула.
     */
    @Bean("virtualThreadExecutor")
    public AsyncTaskExecutor virtualThreadExecutor() {
        // Executors.newVirtualThreadPerTaskExecutor() — Java 21 API
        return new TaskExecutorAdapter(
                Executors.newVirtualThreadPerTaskExecutor()
        );
    }

    /**
     * Настраиваем Spring MVC async support на виртуальные потоки.
     * Применяется для DeferredResult, Callable и т.д.
     */
    @Override
    public void configureAsyncSupport(AsyncSupportConfigurer configurer) {
        configurer.setTaskExecutor(virtualThreadExecutor());
    }
}

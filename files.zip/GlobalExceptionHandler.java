package com.example.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Централизованная обработка ошибок.
 *
 * Принципы:
 *  - Единая точка для всех HTTP-ответов с ошибками.
 *  - RFC 7807 "Problem Details" формат ответа.
 *  - Логируем 5xx как ERROR, 4xx как WARN.
 */
@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    // ── 404 Not Found ─────────────────────────────────────────────────────────

    @ExceptionHandler(CustomerException.NotFound.class)
    public ProblemDetail handleNotFound(CustomerException.NotFound ex, WebRequest req) {
        log.warn("Not found: {}", ex.getMessage());
        var pd = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, ex.getMessage());
        pd.setProperty("timestamp", LocalDateTime.now());
        return pd;
    }

    // ── 409 Conflict ──────────────────────────────────────────────────────────

    @ExceptionHandler(CustomerException.EmailAlreadyExists.class)
    public ProblemDetail handleConflict(CustomerException.EmailAlreadyExists ex) {
        log.warn("Conflict: {}", ex.getMessage());
        var pd = ProblemDetail.forStatusAndDetail(HttpStatus.CONFLICT, ex.getMessage());
        pd.setProperty("timestamp", LocalDateTime.now());
        return pd;
    }

    // ── 400 Validation errors ─────────────────────────────────────────────────

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex,
            HttpHeaders headers, HttpStatusCode status, WebRequest request) {

        Map<String, String> errors = ex.getBindingResult().getFieldErrors().stream()
                .collect(Collectors.toMap(
                        FieldError::getField,
                        fe -> fe.getDefaultMessage() == null ? "invalid" : fe.getDefaultMessage(),
                        (a, b) -> a + "; " + b
                ));

        var pd = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, "Validation failed");
        pd.setProperty("errors", errors);
        pd.setProperty("timestamp", LocalDateTime.now());
        return ResponseEntity.badRequest().body(pd);
    }

    // ── 500 fallback ──────────────────────────────────────────────────────────

    @ExceptionHandler(Exception.class)
    public ProblemDetail handleAll(Exception ex) {
        log.error("Unhandled exception", ex);
        var pd = ProblemDetail.forStatusAndDetail(
                HttpStatus.INTERNAL_SERVER_ERROR, "Internal server error");
        pd.setProperty("timestamp", LocalDateTime.now());
        return pd;
    }
}

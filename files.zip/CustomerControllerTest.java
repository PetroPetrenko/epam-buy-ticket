package com.example.controller;

import com.example.dto.CustomerDto;
import com.example.repository.CustomerRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Интеграционный тест — поднимает полный Spring контекст + H2 в памяти.
 *
 * Принципы:
 *  - @SpringBootTest + MockMvc = максимальная близость к реальному HTTP.
 *  - @TestMethodOrder гарантирует порядок: create → read → update → delete.
 *  - Все данные изолированы в H2 (не ломают production БД).
 */
@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class CustomerControllerTest {

    @Autowired MockMvc mvc;
    @Autowired ObjectMapper mapper;
    @Autowired CustomerRepository repo;

    private static Long createdId;

    private static final String BASE = "/api/v1/customers";

    @Test @Order(1)
    void create_shouldReturn201WithLocation() throws Exception {
        var req = new CustomerDto.CreateRequest("Alice", "alice@example.com", "Kyiv");

        var result = mvc.perform(post(BASE)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(req)))
                .andExpect(status().isCreated())
                .andExpect(header().exists("Location"))
                .andExpect(jsonPath("$.id").isNumber())
                .andExpect(jsonPath("$.email").value("alice@example.com"))
                .andReturn();

        // Сохраняем id для следующих тестов
        var response = mapper.readValue(
                result.getResponse().getContentAsString(), CustomerDto.Response.class);
        createdId = response.id();
    }

    @Test @Order(2)
    void findById_shouldReturn200() throws Exception {
        mvc.perform(get(BASE + "/" + createdId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Alice"));
    }

    @Test @Order(3)
    void findAll_shouldReturnPageResponse() throws Exception {
        mvc.perform(get(BASE).param("page", "0").param("size", "10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content", hasSize(greaterThanOrEqualTo(1))))
                .andExpect(jsonPath("$.totalElements").isNumber());
    }

    @Test @Order(4)
    void search_shouldFindByName() throws Exception {
        mvc.perform(get(BASE + "/search").param("q", "alice"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content[0].email").value("alice@example.com"));
    }

    @Test @Order(5)
    void update_shouldReturn200() throws Exception {
        var req = new CustomerDto.UpdateRequest("Alice Updated", "alice@example.com", "Lviv");

        mvc.perform(put(BASE + "/" + createdId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(req)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.address").value("Lviv"));
    }

    @Test @Order(6)
    void delete_shouldReturn204() throws Exception {
        mvc.perform(delete(BASE + "/" + createdId))
                .andExpect(status().isNoContent());

        // Повторный запрос должен вернуть 404
        mvc.perform(get(BASE + "/" + createdId))
                .andExpect(status().isNotFound());
    }

    @Test @Order(7)
    void create_withInvalidEmail_shouldReturn400() throws Exception {
        var req = new CustomerDto.CreateRequest("Bob", "not-an-email", "Odessa");

        mvc.perform(post(BASE)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(req)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors.email").exists());
    }
}
